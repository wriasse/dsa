pip3 install -r requirements.txt
sudo apt -y install screen
chmod 777 *
python3 neferianmpy
