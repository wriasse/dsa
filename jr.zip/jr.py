from licensing.models import *
from licensing.methods import Key, Helpers

RSAPubKey = "<RSAKeyValue><Modulus>t4Y9kOr0fa4qPLz50orfy4kJnlUMfNBYL5A5oS8hNBoQLskg234y1MuczQWrYwATHUaCsovgzgVKMlDnqfjR2K8nTexDizmWNnw4PSCZrKwjlD51F8SNNZvlMxdRzBeZ+7wIxbnYTuWoZ0hVSPlb39NTyPZBU9X8l698DvAK/xxfYaWqF+Z/1dfDXJ1wo/Bjljgvm44r66IZhm9RrR/wVqPsLYxIUnrICi4yY6q4HvXJwi0Jl6SbKstDw7+/7mTST6NoDniDvNEueDglY2pHF8G8b78ooebMrnu8sllB5fhmzEBgPnsbX1vuvFJsanbiazOvO2SEMF9f5Vt4LNCS/w==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>"
auth = "WyIzNTE5NjMyMyIsIjRZWW9NZU1EaFB4NDN3d1VCRStLbGg5bVpDbmdEZjBId25VdG1SemkiXQ=="
def Authkey():
    key = str(input(" Enter Auth Key :-"))
    result = Key.activate(token=auth,\
        rsa_pub_key=RSAPubKey,\
        product_id=18430, \
        key=key,\
        machine_code=Helpers.GetMachineCode())

    if result[0] == None or not Helpers.IsOnRightMachine(result[0]):
    # an error occurred or the key is invalid or it cannot be activated
    # (eg. the limit of activated devices was achieved)
        print("The license does not work: {0}".format(result[1]))
    else:
    # everything went fine if we are here!
        print("The license is valid!")
        pass
Authkey()